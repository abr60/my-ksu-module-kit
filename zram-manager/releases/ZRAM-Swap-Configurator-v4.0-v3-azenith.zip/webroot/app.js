// ZRAM Manager v3 — Interactive Controller
// Compatible with KernelSU-Next and APatch WebUI environments via 3-arg ksu.exec bridge

// Safe APatch fallback
if (typeof window.apatch !== "undefined" && typeof window.ksu === "undefined") {
  window.ksu = window.apatch;
}

const MOD_DIR = "/data/adb/modules/ZRAMSwapConfigurator";
const CONFIG_FILE = MOD_DIR + "/config.prop";
const DEFAULTS_FILE = MOD_DIR + "/defaults.prop";
const APPLY_SCRIPT = MOD_DIR + "/apply.sh";
const ACTION_SCRIPT = MOD_DIR + "/action.sh";
const LOG_FILE = MOD_DIR + "/apply.log";

// Global Runtime State
const state = {
  isMock: false,
  memTotalKb: 3734440, // default spesn until queried
  memAvailKb: 1540000,
  zramDisksizeBytes: 0,
  zramUsedKb: 0,
  activeAlgo: "lz4",
  supportedAlgos: ["lzo", "lz4", "zstd"],
  swappiness: 100,
  priority: 0,
  config: {},
  defaults: {},
  currentPage: "dashboard"
};

const $ = (id) => document.getElementById(id);

// ==================== KERNELSU EXEC BRIDGE ====================
let _ksuCbCounter = 0;

function sh(cmd, options = {}) {
  return new Promise((resolve, reject) => {
    if (typeof window.ksu !== "undefined" && window.ksu.exec) {
      // Android @JavascriptInterface protocol: ksu.exec(String cmd, String optionsJson, String callbackName)
      const cbName = `__ksu_cb_${Date.now()}_${_ksuCbCounter++}`;
      
      // Safety timeout: 12 seconds max
      const timer = setTimeout(() => {
        if (window[cbName]) {
          delete window[cbName];
          reject(new Error("Command timed out: " + cmd));
        }
      }, 12000);

      window[cbName] = (errno, stdout, stderr) => {
        clearTimeout(timer);
        delete window[cbName];
        if (errno === 0) {
          resolve((stdout || "").trim());
        } else {
          reject(new Error(stderr || `Exit code ${errno}`));
        }
      };

      try {
        window.ksu.exec(cmd, JSON.stringify(options), cbName);
      } catch (err) {
        clearTimeout(timer);
        delete window[cbName];
        reject(err);
      }
    } else {
      // Desktop Preview / Offline Simulation Bridge
      state.isMock = true;
      if ($("demoNotice")) $("demoNotice").style.display = "flex";
      mockBridge(cmd, resolve, reject);
    }
  });
}

function mockBridge(cmd, resolve, reject) {
  setTimeout(() => {
    if (cmd.includes("/proc/meminfo")) {
      resolve("MemTotal:        3734440 kB\nMemFree:          451200 kB\nMemAvailable:    1584320 kB");
    } else if (cmd.includes("/proc/swaps")) {
      resolve("Filename\t\t\t\tType\t\tSize\t\tUsed\t\tPriority\n/dev/block/zram0                        partition\t2427388\t\t245760\t\t0");
    } else if (cmd.includes("/sys/block/zram0/disksize")) {
      resolve("2485645312");
    } else if (cmd.includes("/sys/block/zram0/comp_algorithm")) {
      resolve("lzo [lz4] zstd");
    } else if (cmd.includes("/proc/sys/vm/swappiness")) {
      resolve("100");
    } else if (cmd.includes("cat " + CONFIG_FILE)) {
      resolve("resize=65%\nalgo=lz4\nprio=0\nswps=100\n");
    } else if (cmd.includes("cat > " + CONFIG_FILE)) {
      resolve("");
    } else if (cmd.includes(APPLY_SCRIPT)) {
      resolve("algo: lz4\nresize: 2427388K (now 2485645312 B), prio 0\nswps: 100\n=== done ===");
    } else if (cmd.includes(ACTION_SCRIPT)) {
      resolve("- Free:\n              total        used        free      shared     buffers\nMem:        3734440     2194440     1540000       45000       80000\nSwap:       2427388      245760     2181628\n\n- /proc/swaps:\n/dev/block/zram0 partition 2427388 245760 0\n\n- /sys/block/zram0/comp_algorithm:\nlzo [lz4] zstd");
    } else if (cmd.includes("tail") || cmd.includes(LOG_FILE)) {
      resolve("=== apply live ===\nalgo: lz4\nresize: 2427388K (now 2485645312 B), prio 0\nswps: 100\n=== done ===");
    } else {
      resolve("");
    }
  }, 80);
}

// ==================== FORMATTERS ====================
function formatBytes(bytes) {
  const b = parseInt(bytes || "0", 10);
  if (!b || isNaN(b)) return { num: "0", unit: "MB", full: "0 MB" };
  if (b >= 1024 * 1024 * 1024) {
    const val = (b / (1024 * 1024 * 1024)).toFixed(2);
    return { num: val, unit: "GB", full: val + " GB" };
  }
  if (b >= 1024 * 1024) {
    const val = (b / (1024 * 1024)).toFixed(0);
    return { num: val, unit: "MB", full: val + " MB" };
  }
  const val = (b / 1024).toFixed(0);
  return { num: val, unit: "KB", full: val + " KB" };
}

function formatKb(kb) {
  return formatBytes(parseInt(kb || "0", 10) * 1024);
}

function parseProps(text) {
  const map = {};
  (text || "").split("\n").forEach((line) => {
    line = line.trim();
    if (!line || line.startsWith("#")) return;
    const idx = line.indexOf("=");
    if (idx > -1) {
      map[line.substring(0, idx).trim()] = line.substring(idx + 1).trim();
    }
  });
  return map;
}

function toast(msg, ok = true) {
  const t = $("toast");
  const m = $("toastMsg");
  m.textContent = msg;
  t.className = "toast-bubble " + (ok ? "ok" : "err") + " show";
  setTimeout(() => {
    t.classList.remove("show");
  }, 3200);
}

// ==================== LIVE STATUS ====================
async function refreshStatus() {
  const icon = $("refreshIcon");
  icon.classList.add("spin-anim");

  try {
    const [meminfo, swaps, disksize, algos, swps] = await Promise.all([
      sh("cat /proc/meminfo"),
      sh("cat /proc/swaps"),
      sh("cat /sys/block/zram0/disksize 2>/dev/null || echo 0"),
      sh("cat /sys/block/zram0/comp_algorithm 2>/dev/null || echo ''"),
      sh("cat /proc/sys/vm/swappiness 2>/dev/null || echo 100")
    ]);

    // Meminfo
    const memTotalM = meminfo.match(/MemTotal:\s+(\d+)\s+kB/);
    const memAvailM = meminfo.match(/MemAvailable:\s+(\d+)\s+kB/);
    if (memTotalM) state.memTotalKb = parseInt(memTotalM[1], 10);
    if (memAvailM) state.memAvailKb = parseInt(memAvailM[1], 10);

    // Swaps
    const swapsLines = swaps.split("\n");
    let zramActive = false;
    let usedKb = 0;
    let sizeKb = 0;
    let prio = 0;

    for (const l of swapsLines) {
      if (l.includes("zram0")) {
        zramActive = true;
        const p = l.trim().split(/\s+/);
        if (p.length >= 5) {
          sizeKb = parseInt(p[2], 10) || 0;
          usedKb = parseInt(p[3], 10) || 0;
          prio = parseInt(p[4], 10) || 0;
        }
      }
    }

    state.zramDisksizeBytes = parseInt(disksize.trim() || "0", 10);
    state.zramUsedKb = usedKb;
    state.swappiness = parseInt(swps.trim() || "100", 10);
    state.priority = prio;

    // Parse Algorithms (active is in brackets, e.g. "lzo [lz4] zstd")
    if (algos) {
      const parsed = [];
      let active = "";
      algos.trim().split(/\s+/).forEach((chunk) => {
        if (chunk.startsWith("[") && chunk.endsWith("]")) {
          const name = chunk.slice(1, -1);
          active = name;
          parsed.push(name);
        } else if (chunk) {
          parsed.push(chunk);
        }
      });
      state.supportedAlgos = parsed;
      if (active) state.activeAlgo = active;
    }

    // Update Hero Card UI
    const heroCard = $("heroCard");
    const statusText = $("heroStatusText");
    const algoTag = $("heroAlgoBadge");
    const prioTag = $("heroPrioBadge");
    const numEl = $("heroSizeNum");
    const unitEl = $("heroSizeUnit");
    const detailEl = $("heroAllocDetail");
    const gaugeText = $("gaugeValueText");
    const gaugeBar = $("gaugeFillBar");

    if (zramActive && state.zramDisksizeBytes > 0) {
      heroCard.className = "core-card active";
      statusText.textContent = "ZRAM ACTIVE";
      algoTag.textContent = state.activeAlgo;
      prioTag.textContent = "prio " + state.priority;

      const sizeObj = formatBytes(state.zramDisksizeBytes);
      const usedObj = formatKb(state.zramUsedKb);
      numEl.textContent = sizeObj.num;
      unitEl.textContent = sizeObj.unit;

      detailEl.textContent = `${sizeObj.full} allocated · /dev/block/zram0`;

      const pct = sizeKb > 0 ? Math.round((state.zramUsedKb / sizeKb) * 100) : 0;
      gaugeText.textContent = `${usedObj.full} / ${sizeObj.full} (${pct}%)`;
      gaugeBar.style.width = Math.min(100, Math.max(0, pct)) + "%";
    } else {
      heroCard.className = "core-card disabled";
      statusText.textContent = "ZRAM DISABLED";
      algoTag.textContent = "none";
      prioTag.textContent = "off";
      numEl.textContent = "0";
      unitEl.textContent = "MB";
      detailEl.textContent = "Swap is disabled or reset to 0 bytes";
      gaugeText.textContent = "0 MB / 0 MB (0%)";
      gaugeBar.style.width = "0%";
    }

    // 2x2 Stats
    const ramTotalObj = formatKb(state.memTotalKb);
    const ramAvailObj = formatKb(state.memAvailKb);
    $("statRamTotal").textContent = ramTotalObj.full;
    $("statRamAvail").textContent = "Avail: " + ramAvailObj.full;

    const zramRatio = state.memTotalKb > 0
      ? Math.round((state.zramDisksizeBytes / (state.memTotalKb * 1024)) * 100)
      : 0;
    $("statZramRatio").textContent = zramRatio + "%";
    $("statZramExact").textContent = formatBytes(state.zramDisksizeBytes).full;

    $("statAlgo").textContent = state.activeAlgo;
    $("statSwappiness").textContent = String(state.swappiness);

    $("supportedAlgosText").textContent = state.supportedAlgos.join(", ") || "lz4";

    // Refresh algorithm chips in Configure tab
    renderAlgoChips();
    updateSliderCalculation();

  } catch (e) {
    console.error("Status error:", e);
    toast("Status error: " + e.message, false);
  } finally {
    setTimeout(() => icon.classList.remove("spin-anim"), 350);
  }
}

// ==================== ALGORITHM CHIPS ====================
function renderAlgoChips() {
  const wrap = $("algoChipsWrap");
  if (!wrap) return;
  const curr = $("algo").value || state.activeAlgo;

  wrap.innerHTML = "";
  state.supportedAlgos.forEach((algo) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "sel-chip" + (curr === algo ? " active" : "");
    btn.dataset.algo = algo;
    btn.textContent = algo + (algo === "lz4" ? " (Fastest)" : "");
    btn.onclick = () => selectAlgorithm(algo);
    wrap.appendChild(btn);
  });
}

function selectAlgorithm(algo) {
  $("algo").value = algo;
  document.querySelectorAll("#algoChipsWrap .sel-chip").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.algo === algo);
  });
}

// ==================== ALLOCATION CALCULATOR & SLIDER ====================
function updateSliderCalculation() {
  const slider = $("resizeSlider");
  const custom = $("resize");
  const pill = $("targetCalculatedPill");
  if (!slider || !custom || !pill) return;

  const raw = custom.value.trim();
  let pct = parseInt(slider.value, 10);

  if (raw.endsWith("%")) {
    const p = parseInt(raw.replace("%", ""), 10);
    if (!isNaN(p)) pct = p;
  }

  if (raw === "0" || pct === 0) {
    pill.textContent = "0% · Swap Disabled";
    pill.style.color = "var(--rose)";
    return;
  }

  pill.style.color = "var(--mint)";

  if (!isNaN(pct)) {
    const bytes = Math.floor((state.memTotalKb * 1024 * pct) / 100);
    pill.textContent = `${pct}% ≈ ${formatBytes(bytes).full}`;
  } else if (!isNaN(parseInt(raw, 10))) {
    pill.textContent = formatBytes(parseInt(raw, 10)).full + " (raw bytes)";
  } else {
    pill.textContent = "50% ≈ 1.86 GB";
  }
}

function setTargetPercent(pct) {
  $("resizeSlider").value = pct;
  $("resize").value = pct === 0 ? "0" : pct + "%";
  updateSliderCalculation();

  // Highlight matching profile pill if any
  document.querySelectorAll(".profile-pill-card").forEach((c) => {
    const p = parseInt(c.querySelector(".profile-pct").textContent, 10);
    c.classList.toggle("active", p === pct);
  });
}

// ==================== PROFILES ====================
window.selectPreset = function(name) {
  switch (name) {
    case "battery":
      setTargetPercent(35);
      selectAlgorithm("lz4");
      setSwappiness(60);
      $("prio").value = "0";
      toast("Eco Saver profile loaded (35% · lz4)");
      break;

    case "balanced":
      setTargetPercent(50);
      selectAlgorithm("lz4");
      setSwappiness(80);
      $("prio").value = "0";
      toast("Balanced profile loaded (50% · lz4)");
      break;

    case "performance":
      setTargetPercent(65);
      selectAlgorithm("lz4");
      setSwappiness(100);
      $("prio").value = "0";
      toast("Performance profile loaded (65% · lz4)");
      break;

    case "gaming":
      setTargetPercent(75);
      selectAlgorithm("lz4");
      setSwappiness(100);
      $("prio").value = "0";
      $("sflp").value = "10";
      $("sum").value = "90";
      toast("Gaming Beast profile loaded (75% · tuned LMKD)");
      break;

    case "disable":
      setTargetPercent(0);
      toast("Swap disabled (0%)");
      break;
  }
};

window.setSwappiness = function(val) {
  $("swps").value = val;
  document.querySelectorAll(".chip-step-btn").forEach((b) => {
    b.classList.toggle("active", parseInt(b.textContent, 10) === val);
  });
};

window.setField = function(id, val) {
  if ($(id)) {
    $(id).value = val;
    toast(`Set ${id} = "${val || 'clear'}"`);
  }
};

window.toggleSwapRatio = function() {
  const cur = $("swpre").value;
  $("swpre").value = cur === "1" ? "0" : "1";
  toast(`swap_ratio_enable: ${$("swpre").value}`);
};

// ==================== NAVIGATION TABS ====================
function navigateTo(pageId) {
  state.currentPage = pageId;

  document.querySelectorAll(".nav-tab").forEach((tab) => {
    tab.classList.toggle("active", tab.dataset.page === pageId);
  });

  document.querySelectorAll(".page-view").forEach((view) => {
    view.classList.toggle("active", view.id === "page-" + pageId);
  });

  if (pageId === "advanced") {
    loadLogConsole();
  }
}

// ==================== CONFIG FILE & APPLY ENGINE ====================
async function loadConfig() {
  try {
    const text = await sh("cat " + CONFIG_FILE + " 2>/dev/null || echo ''");
    state.config = parseProps(text);
    const c = state.config;

    // Resize
    if (c.resize) {
      $("resize").value = c.resize;
      if (c.resize.includes("%")) {
        const p = parseInt(c.resize.replace("%", ""), 10);
        if (!isNaN(p)) setTargetPercent(p);
      } else if (c.resize === "0") {
        setTargetPercent(0);
      }
    } else {
      setTargetPercent(50);
    }

    // Algo
    if (c.algo) selectAlgorithm(c.algo);

    // Prio
    if (c.prio) $("prio").value = c.prio;

    // Swappiness
    if (c.swps) {
      setSwappiness(parseInt(c.swps, 10) || 100);
    }

    // Sysctls
    if (c.swpre) $("swpre").value = c.swpre;
    if (c.swpr) $("swpr").value = c.swpr;
    if (c.mfkb) $("mfkb").value = c.mfkb;
    if (c.efkb) $("efkb").value = c.efkb;

    // LMKD
    ["sflp", "sum", "scr", "scrd", "med", "low"].forEach((k) => {
      if ($(k) && c[k]) $(k).value = c[k];
    });

  } catch (err) {
    console.warn("Config load error:", err);
  }
}

function assembleConfigContent() {
  const lines = [
    "# ZRAM Manager v3",
    "# Managed via WebUI — applied at boot or live"
  ];

  const put = (k, v) => {
    if (v !== null && v !== undefined && String(v).trim() !== "") {
      lines.push(`${k}=${String(v).trim()}`);
    }
  };

  const r = $("resize").value.trim();
  put("resize", r || "50%");
  put("algo", $("algo").value.trim());
  put("prio", $("prio").value.trim());
  put("swps", $("swps").value.trim());
  put("swpre", $("swpre").value.trim());
  put("swpr", $("swpr").value.trim());
  put("mfkb", $("mfkb").value.trim());
  put("efkb", $("efkb").value.trim());

  ["sflp", "sum", "scr", "scrd", "med", "low"].forEach((k) => {
    if ($(k)) put(k, $(k).value.trim());
  });

  return lines.join("\n") + "\n";
}

async function writeConfigFile(content) {
  return sh(`cat > ${CONFIG_FILE} <<'EOF'\n${content}EOF`);
}

async function handleApplyLive() {
  const modal = $("applyModal");
  const badge = $("modalBadge");

  modal.classList.add("show");
  badge.textContent = "Saving config.prop...";

  try {
    const configContent = assembleConfigContent();
    // Bench: snapshot the OUTGOING session (old config + old counters
    // still live) before overwriting config.prop. Survives reboot in
    // /data/adb/zram-manager/bench.log.
    badge.textContent = "Logging session stats...";
    await sh(`sh ${MOD_DIR}/bench.sh snapshot session 2>&1 || true`);

    await writeConfigFile(configContent);

    badge.textContent = "Rebooting...";
    toast("Config saved — rebooting now!", true);
    await sh(`svc power reboot`);

  } catch (e) {
    modal.classList.remove("show");
    toast("Apply failed: " + e.message, false);
  }
}

// ==================== LOGS & DIAGNOSTICS ====================
async function loadLogConsole() {
  const consoleEl = $("logConsole");
  consoleEl.textContent = "Reading apply.log...";
  try {
    const out = await sh(`tail -n 50 ${LOG_FILE} 2>/dev/null || echo "No logs found."`);
    consoleEl.textContent = out.trim();
    consoleEl.scrollTop = consoleEl.scrollHeight;
  } catch (e) {
    consoleEl.textContent = "Error reading log: " + e.message;
  }
}

async function runDiagnostics() {
  const consoleEl = $("logConsole");
  consoleEl.textContent = "Running action.sh diagnostics...";
  try {
    const out = await sh(`sh ${ACTION_SCRIPT} 2>&1`);
    consoleEl.textContent = out.trim() || "Diagnostics completed.";
    toast("Diagnostics executed!");
  } catch (e) {
    consoleEl.textContent = "Diagnostics failed: " + e.message;
    toast("Diagnostics error: " + e.message, false);
  }
}

function copyLog() {
  const t = $("logConsole").textContent;
  if (!t) return;
  navigator.clipboard.writeText(t).then(() => {
    toast("Log copied to clipboard!");
  }).catch(() => toast("Failed to copy", false));
}

async function snapshotNow() {
  const consoleEl = $("logConsole");
  consoleEl.textContent = "Logging bench snapshot...";
  try {
    const out = await sh(`sh ${MOD_DIR}/bench.sh snapshot manual 2>&1`);
    consoleEl.textContent = (out.trim() || "Snapshot logged.") + "\n\nSaved to /data/adb/zram-manager/bench.log (survives reboots + updates).";
    consoleEl.scrollTop = consoleEl.scrollHeight;
    toast("Snapshot logged!");
  } catch (e) {
    consoleEl.textContent = "Snapshot failed: " + e.message;
    toast("Snapshot error: " + e.message, false);
  }
}

async function runBenchReport() {
  const consoleEl = $("logConsole");
  consoleEl.textContent = "Building per-config report...";
  try {
    const out = await sh(`sh ${MOD_DIR}/bench.sh report 2>&1`);
    consoleEl.textContent = out.trim() || "No bench data yet.";
    consoleEl.scrollTop = consoleEl.scrollHeight;
    toast("Report ready!");
  } catch (e) {
    consoleEl.textContent = "Report failed: " + e.message;
    toast("Report error: " + e.message, false);
  }
}

// ==================== EVENT LISTENERS ====================
function init() {
  // Navigation Tabs
  document.querySelectorAll(".nav-tab").forEach((tab) => {
    tab.addEventListener("click", () => navigateTo(tab.dataset.page));
  });

  // Slider
  $("resizeSlider").addEventListener("input", (e) => {
    const val = parseInt(e.target.value, 10);
    $("resize").value = val === 0 ? "0" : val + "%";
    updateSliderCalculation();
  });

  // Text input sync
  $("resize").addEventListener("input", () => {
    updateSliderCalculation();
  });

  // Action Buttons
  $("btnRefresh").addEventListener("click", refreshStatus);
  $("btnApplyLive").addEventListener("click", handleApplyLive);

  // Diagnostic Buttons
  $("btnRunDiag").addEventListener("click", runDiagnostics);
  $("btnCopyLog").addEventListener("click", copyLog);
  $("btnBenchSnap").addEventListener("click", snapshotNow);
  $("btnBenchReport").addEventListener("click", runBenchReport);
}

// Boot
window.addEventListener("DOMContentLoaded", async () => {
  init();
  await loadConfig();
  await refreshStatus();
});