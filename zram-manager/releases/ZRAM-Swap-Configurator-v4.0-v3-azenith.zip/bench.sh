#!/system/bin/sh

# ZRAM Manager — persistent per-config benchmark log
#
#   bench.sh snapshot <boot|session|manual>   append one stats line
#   bench.sh report                            per-resize summary table
#
# The log lives OUTSIDE the module dir (/data/adb/zram-manager/bench.log)
# so it survives reboots AND module updates (the module dir is replaced
# on every update). One line per event, space-separated key=value.
#
# Flow: WebUI runs "snapshot session" BEFORE writing a new config
# (old config + old counters still live) -> reboot -> service.sh logs
# "snapshot boot" (fresh counters) -> next switch closes that session.
# With Apply & Reboot there is exactly one config per boot, so the
# uptime at snapshot time ~= that config's session length.

MODDIR=/data/adb/modules/ZRAMSwapConfigurator
BENCH_DIR=/data/adb/zram-manager
BENCH_LOG=$BENCH_DIR/bench.log
CONFIG=$MODDIR/config.prop
ZRAM_SYS=/sys/block/zram0

cfg() { # $1=key -> value or empty
  [ -f "$CONFIG" ] || return 0
  sed -n "s|^$1=||p" "$CONFIG" | tail -n1
}

snapshot() { # $1=event
  mkdir -p "$BENCH_DIR" 2>/dev/null || return 1

  TS=`date +%Y-%m-%dT%H:%M:%S 2>/dev/null`
  UP=`awk '{print int($1)}' /proc/uptime 2>/dev/null`
  [ -z "$UP" ] && UP=0

  set -- `cat $ZRAM_SYS/mm_stat 2>/dev/null`
  ORIG=${1:-0}; COMPR=${2:-0}
  RATIO=`awk -v o="$ORIG" -v c="$COMPR" 'BEGIN { if (c+0 > 0) printf "%.2f", o/c; else print "0" }'`
  DISK=`cat $ZRAM_SYS/disksize 2>/dev/null`
  [ -z "$DISK" ] && DISK=0

  MAVA=`awk '/^MemAvailable:/ {print $2; exit}' /proc/meminfo 2>/dev/null`
  STOT=`awk '/^SwapTotal:/ {print $2; exit}' /proc/meminfo 2>/dev/null`
  SFR=`awk '/^SwapFree:/ {print $2; exit}' /proc/meminfo 2>/dev/null`
  [ -z "$MAVA" ] && MAVA=0; [ -z "$STOT" ] && STOT=0; [ -z "$SFR" ] && SFR=0

  PIN=`awk '/^pswpin/ {print $2; exit}' /proc/vmstat 2>/dev/null`
  POUT=`awk '/^pswpout/ {print $2; exit}' /proc/vmstat 2>/dev/null`
  [ -z "$PIN" ] && PIN=0; [ -z "$POUT" ] && POUT=0

  PSOME=`awk '/^some/ {for(i=1;i<=NF;i++) if ($i ~ /^avg300=/) {sub(/avg300=/,"",$i); print $i; exit}}' /proc/pressure/memory 2>/dev/null`
  PFULL=`awk '/^full/ {for(i=1;i<=NF;i++) if ($i ~ /^avg300=/) {sub(/avg300=/,"",$i); print $i; exit}}' /proc/pressure/memory 2>/dev/null`
  [ -z "$PSOME" ] && PSOME=0; [ -z "$PFULL" ] && PFULL=0

  LINE="ts=$TS event=$1 resize=`cfg resize` algo=`cfg algo` prio=`cfg prio` swps=`cfg swps` uptime_s=$UP disksize_B=$DISK orig_B=$ORIG compr_B=$COMPR ratio_x=$RATIO memavail_kb=$MAVA swaptotal_kb=$STOT swapfree_kb=$SFR pswpin=$PIN pswpout=$POUT psi_some300=$PSOME psi_full300=$PFULL"
  echo "$LINE" >>$BENCH_LOG
  echo "$LINE"
}

report() {
  [ -f "$BENCH_LOG" ] || { echo "No bench data yet - switch configs a few times first."; return 0; }
  awk '
  function kv(n,  i,a) { for (i=1;i<=NF;i++) { split($i,a,"="); if (a[1]==n) return a[2]; } return ""; }
  /^ts=/ {
    e=kv("event"); if (e=="boot" || e=="") next;
    r=kv("resize"); if (r=="") r="(unset)";
    if (!(r in n)) { n[r]=0; order[++nr]=r; }
    n[r]++;
    u=kv("uptime_s")+0; t[r]+=u;
    nra[r]+=kv("ratio_x")+0;
    st=kv("swaptotal_kb")+0; sf=kv("swapfree_kb")+0;
    if (st > 0) { util[r]+=((st-sf)/st*100); nu[r]++; }
    f[r]+=kv("psi_full300")+0;
    ch[r]+=(kv("pswpin")+kv("pswpout"))*4/1024;  # MB moved
  }
  END {
    printf "%-9s %4s %7s %7s %9s %9s %10s\n", "resize", "sess", "hours", "ratio", "swapuse%", "fullstl", "churnMB/h";
    for (i=1;i<=nr;i++) { r=order[i];
      h=t[r]/3600;
      printf "%-9s %4d %7.1f %7.2f %9.1f %9.2f %10.0f\n", r, n[r], h, \
        (n[r]?nra[r]/n[r]:0), (nu[r]?util[r]/nu[r]:0), (n[r]?f[r]/n[r]:0), (h>0?ch[r]/h:0);
    }
    print "(sess=sessions, ratio=compression, swapuse%=avg zram fill, fullstl=avg full-stall avg300, churn=swap traffic rate)";
  }' "$BENCH_LOG"
}

case "$1" in
  snapshot) snapshot "$2" ;;
  report)   report ;;
  *) echo "usage: bench.sh snapshot <boot|session|manual> | report" >&2; exit 1 ;;
esac
