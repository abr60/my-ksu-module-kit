// ZRAM Swap Configurator v4.0 — Interactive WebUI Controller
// Supports KernelSU-Next and APatch WebUI environments via ksu.exec bridge
// Features Zygisk Next inspired dark UI, real-time memory calculators, tuned profiles, and live apply.

// Safe bridge assignment
if (typeof window.apatch !== "undefined" && typeof window.ksu === "undefined") {
  window.ksu = window.apatch;
}

const MOD_DIR = "/data/adb/modules/ZRAMSwapConfigurator";
const CONFIG_FILE = MOD_DIR + "/config.prop";
const DEFAULTS_FILE = MOD_DIR + "/defaults.prop";
const APPLY_SCRIPT = MOD_DIR + "/apply.sh";
const ACTION_SCRIPT = MOD_DIR + "/action.sh";
const LOG_FILE = MOD_DIR + "/apply.log";

// Global Device & UI State
const state = {
  isMock: false,
  memTotalKb: 3734440, // default spesn 4GB until fetched
  memAvailKb: 1540000,
  zramDisksizeBytes: 0,
  zramUsedKb: 0,
  activeAlgo: "lz4",
  supportedAlgos: ["lzo", "lz4", "zstd"],
  swappiness: 100,
  priority: 0,
  config: {},
  defaults: {},
  currentTab: "tuning"
};

const $ = (id) => document.getElementById(id);

// ==================== ROOT SHELL BRIDGE ====================
function sh(cmd) {
  return new Promise((resolve, reject) => {
    if (typeof window.ksu !== "undefined" && window.ksu.exec) {
      window.ksu.exec(cmd, (code, stdout, stderr) => {
        if (code === 0) {
          resolve((stdout || "").trim());
        } else {
          reject(new Error(stderr || `Exit code ${code}`));
        }
      });
    } else {
      // Offline / Desktop Browser Preview Mode
      state.isMock = true;
      $("demoNotice").style.display = "flex";
      handleMockCmd(cmd, resolve, reject);
    }
  });
}

// Simulated replies when running outside KernelSU Manager
function handleMockCmd(cmd, resolve, reject) {
  setTimeout(() => {
    if (cmd.includes("/proc/meminfo")) {
      resolve("MemTotal:        3734440 kB\nMemFree:          451200 kB\nMemAvailable:    1584320 kB");
    } else if (cmd.includes("/proc/swaps")) {
      resolve("Filename\t\t\t\tType\t\tSize\t\tUsed\t\tPriority\n/dev/block/zram0                        partition\t2427388\t\t245760\t\t0");
    } else if (cmd.includes("/sys/block/zram0/disksize")) {
      resolve("2485645312");
    } else if (cmd.includes("/sys/block/zram0/comp_algorithm")) {
      resolve("lzo [lz4] zstd");
    } else if (cmd.includes("/proc/sys/vm/swappiness")) {
      resolve("100");
    } else if (cmd.includes("cat " + CONFIG_FILE)) {
      resolve("resize=65%\nalgo=lz4\nprio=0\nswps=100\n");
    } else if (cmd.includes("cat > " + CONFIG_FILE)) {
      resolve("");
    } else if (cmd.includes(APPLY_SCRIPT)) {
      resolve("=== apply mock ===\nalgo: lz4\nresize: 2427388K (now 2485645312 B), prio 0\nswps: 100\n=== done ===");
    } else if (cmd.includes(ACTION_SCRIPT)) {
      resolve("- Free:\n              total        used        free      shared     buffers\nMem:        3734440     2194440     1540000       45000       80000\nSwap:       2427388      245760     2181628\n\n- /proc/swaps:\n/dev/block/zram0 partition 2427388 245760 0\n\n- /sys/block/zram0/comp_algorithm:\nlzo [lz4] zstd");
    } else if (cmd.includes("tail") || cmd.includes(LOG_FILE)) {
      resolve("=== apply Sat Sep 5 05:00:00 2026 ===\nalgo: lz4\nresize: 2427388K (now 2485645312 B), prio 0\nswps: 100\n=== done ===");
    } else {
      resolve("");
    }
  }, 120);
}

// ==================== HELPERS ====================
function formatBytes(bytes) {
  const b = parseInt(bytes || "0", 10);
  if (!b || isNaN(b)) return "0 B";
  if (b >= 1024 * 1024 * 1024) {
    return (b / (1024 * 1024 * 1024)).toFixed(2) + " GB";
  }
  if (b >= 1024 * 1024) {
    return (b / (1024 * 1024)).toFixed(0) + " MB";
  }
  if (b >= 1024) {
    return (b / 1024).toFixed(0) + " KB";
  }
  return b + " B";
}

function formatKb(kb) {
  return formatBytes(parseInt(kb || "0", 10) * 1024);
}

function parsePropLines(text) {
  const out = {};
  (text || "").split("\n").forEach((line) => {
    line = line.trim();
    if (!line || line.startsWith("#")) return;
    const idx = line.indexOf("=");
    if (idx > -1) {
      const key = line.substring(0, idx).trim();
      const val = line.substring(idx + 1).trim();
      out[key] = val;
    }
  });
  return out;
}

function showToast(text, isOk = true) {
  const toast = $("toast");
  const msg = $("toastMsg");
  const icon = $("toastIcon");

  msg.textContent = text;
  toast.className = "toast " + (isOk ? "ok" : "err") + " show";
  icon.innerHTML = isOk
    ? `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#63e2b7" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>`
    : `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#e88080" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`;

  setTimeout(() => {
    toast.classList.remove("show");
  }, 3200);
}

// ==================== LIVE STATUS REFRESH ====================
async function refreshStatus() {
  const refreshIcon = $("refreshIcon");
  refreshIcon.classList.add("rotating");

  try {
    const [meminfo, swaps, disksize, algos, swps] = await Promise.all([
      sh("cat /proc/meminfo"),
      sh("cat /proc/swaps"),
      sh("cat /sys/block/zram0/disksize 2>/dev/null || echo 0"),
      sh("cat /sys/block/zram0/comp_algorithm 2>/dev/null || echo ''"),
      sh("cat /proc/sys/vm/swappiness 2>/dev/null || echo 100")
    ]);

    // Parse Meminfo
    const memTotalMatch = meminfo.match(/MemTotal:\s+(\d+)\s+kB/);
    const memAvailMatch = meminfo.match(/MemAvailable:\s+(\d+)\s+kB/);
    if (memTotalMatch) state.memTotalKb = parseInt(memTotalMatch[1], 10);
    if (memAvailMatch) state.memAvailKb = parseInt(memAvailMatch[1], 10);

    // Parse Swaps
    const swapsLines = swaps.split("\n");
    let zramActive = false;
    let usedSwapKb = 0;
    let sizeSwapKb = 0;
    let prio = 0;

    for (const line of swapsLines) {
      if (line.includes("zram0")) {
        zramActive = true;
        const parts = line.trim().split(/\s+/);
        if (parts.length >= 5) {
          sizeSwapKb = parseInt(parts[2], 10) || 0;
          usedSwapKb = parseInt(parts[3], 10) || 0;
          prio = parseInt(parts[4], 10) || 0;
        }
      }
    }

    state.zramDisksizeBytes = parseInt(disksize.trim() || "0", 10);
    state.zramUsedKb = usedSwapKb;
    state.swappiness = parseInt(swps.trim() || "100", 10);
    state.priority = prio;

    // Parse Algorithms (active is in brackets, e.g. "lzo [lz4] zstd")
    if (algos) {
      const parsedAlgos = [];
      const parts = algos.trim().split(/\s+/);
      let active = "";
      parts.forEach((p) => {
        if (p.startsWith("[") && p.endsWith("]")) {
          const name = p.slice(1, -1);
          active = name;
          parsedAlgos.push(name);
        } else if (p) {
          parsedAlgos.push(p);
        }
      });
      state.supportedAlgos = parsedAlgos;
      if (active) state.activeAlgo = active;
    }

    // Update Hero Card
    const heroCard = $("heroCard");
    const heroTitle = $("heroStatusText");
    const heroDetail = $("heroDetailText");
    const heroAlgo = $("heroAlgoBadge");
    const heroPrio = $("heroPrioBadge");
    const gaugeFill = $("gaugeFill");
    const gaugeText = $("gaugeUsageText");

    if (zramActive && state.zramDisksizeBytes > 0) {
      heroCard.className = "zn-hero-card active";
      heroTitle.textContent = "ZRAM Active";
      heroAlgo.textContent = state.activeAlgo;
      heroPrio.textContent = "prio " + state.priority;

      const sizeFmt = formatBytes(state.zramDisksizeBytes);
      const usedFmt = formatKb(state.zramUsedKb);
      const pctUsed = sizeSwapKb > 0 ? Math.round((state.zramUsedKb / sizeSwapKb) * 100) : 0;

      heroDetail.textContent = `${sizeFmt} allocated · /dev/block/zram0`;
      gaugeText.textContent = `${usedFmt} / ${sizeFmt} (${pctUsed}%)`;
      gaugeFill.style.width = Math.min(100, Math.max(0, pctUsed)) + "%";
    } else {
      heroCard.className = "zn-hero-card disabled";
      heroTitle.textContent = "ZRAM Inactive";
      heroAlgo.textContent = "none";
      heroPrio.textContent = "off";
      heroDetail.textContent = "Swap is disabled or reset to 0 bytes";
      gaugeText.textContent = "0 MB / 0 MB (0%)";
      gaugeFill.style.width = "0%";
    }

    // Update 2x2 Metric Cards
    $("metricTotalRam").textContent = formatKb(state.memTotalKb);
    $("metricAvailRam").textContent = "Avail: " + formatKb(state.memAvailKb);

    $("metricZramSize").textContent = formatBytes(state.zramDisksizeBytes);
    const pctOfRam = state.memTotalKb > 0
      ? Math.round((state.zramDisksizeBytes / (state.memTotalKb * 1024)) * 100)
      : 0;
    $("metricZramPct").textContent = `${pctOfRam}% of RAM`;

    $("metricAlgo").textContent = state.activeAlgo;
    $("metricSwappiness").textContent = String(state.swappiness);

    // Update Algorithm Selection Chips
    renderAlgoChips();

    // Update Live Calculation Pill for Slider
    updateCalculatedPill();

  } catch (err) {
    console.error("Status refresh error:", err);
    showToast("Refresh error: " + err.message, false);
  } finally {
    setTimeout(() => {
      refreshIcon.classList.remove("rotating");
    }, 400);
  }
}

// ==================== ALGORITHM CHIPS ====================
function renderAlgoChips() {
  const container = $("algoChipGroup");
  const currentVal = $("algo").value || state.activeAlgo;

  container.innerHTML = "";

  // Add Default option
  const defBtn = document.createElement("button");
  defBtn.type = "button";
  defBtn.className = "chip-btn algo-btn" + (currentVal === "" ? " active" : "");
  defBtn.dataset.algo = "";
  defBtn.textContent = "Default";
  defBtn.onclick = () => selectAlgo("");
  container.appendChild(defBtn);

  // Add all detected supported algorithms
  state.supportedAlgos.forEach((algo) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "chip-btn algo-btn" + (currentVal === algo ? " active" : "");
    btn.dataset.algo = algo;
    btn.textContent = algo + (algo === "lz4" ? " (Fastest)" : algo === "zstd" ? " (Dense)" : "");
    btn.onclick = () => selectAlgo(algo);
    container.appendChild(btn);
  });

  $("algoSupportedHint").textContent = "Kernel supported: " + state.supportedAlgos.join(", ");
}

function selectAlgo(algo) {
  $("algo").value = algo;
  document.querySelectorAll(".algo-btn").forEach((b) => {
    b.classList.toggle("active", b.dataset.algo === algo);
  });
}

// ==================== ZRAM SIZE SLIDER & CALCULATOR ====================
function updateCalculatedPill() {
  const slider = $("resizeSlider");
  const customInput = $("resize");
  const pill = $("resizeCalculatedPill");

  const val = customInput.value.trim();
  let pct = parseInt(slider.value, 10);

  if (val.endsWith("%")) {
    const p = parseInt(val.replace("%", ""), 10);
    if (!isNaN(p)) pct = p;
  }

  if (val === "0" || pct === 0) {
    pill.textContent = "0% · ZRAM Disabled";
    pill.style.color = "var(--accent-danger)";
    return;
  }

  pill.style.color = "var(--primary)";

  if (!isNaN(pct)) {
    const calculatedBytes = Math.floor((state.memTotalKb * 1024 * pct) / 100);
    pill.textContent = `${pct}% ≈ ${formatBytes(calculatedBytes)}`;
  } else if (!isNaN(parseInt(val, 10))) {
    const raw = parseInt(val, 10);
    pill.textContent = `${formatBytes(raw)} (custom)`;
  } else {
    pill.textContent = "50% (Default)";
  }
}

function setSizeFromPct(pct) {
  $("resizeSlider").value = pct;
  $("resize").value = pct === 0 ? "0" : pct + "%";
  updateCalculatedPill();

  // Update quick chip button highlights
  document.querySelectorAll("#quickSizeChips .chip-btn").forEach((btn) => {
    const chipSize = parseInt(btn.dataset.size, 10);
    btn.classList.toggle("active", chipSize === pct);
  });
}

// ==================== LOAD & PERSIST CONFIG ====================
async function loadConfig() {
  try {
    const [cfgText, defText] = await Promise.all([
      sh("cat " + CONFIG_FILE + " 2>/dev/null || echo ''"),
      sh("cat " + DEFAULTS_FILE + " 2>/dev/null || echo ''")
    ]);

    state.config = parsePropLines(cfgText);
    state.defaults = parsePropLines(defText);

    // Apply values to UI
    const c = state.config;

    // Resize
    if (c.resize) {
      $("resize").value = c.resize;
      if (c.resize.includes("%")) {
        const p = parseInt(c.resize.replace("%", ""), 10);
        if (!isNaN(p)) {
          $("resizeSlider").value = p;
          setSizeFromPct(p);
        }
      } else if (c.resize === "0") {
        setSizeFromPct(0);
      }
    } else {
      // Default 50%
      setSizeFromPct(50);
    }

    // Algorithm
    if (c.algo) {
      selectAlgo(c.algo);
    }

    // Priority
    if (c.prio) $("prio").value = c.prio;

    // Swappiness
    if (c.swps) {
      $("swps").value = c.swps;
      $("swpsSlider").value = c.swps;
      $("swpsValDisplay").textContent = c.swps;
    } else {
      $("swpsValDisplay").textContent = "100 (def)";
    }

    // Swap ratio enable
    if (c.swpre === "1") {
      $("swpreCheck").checked = true;
      $("swpre").value = "1";
    } else if (c.swpre === "0") {
      $("swpreCheck").checked = false;
      $("swpre").value = "0";
    } else {
      $("swpreCheck").checked = false;
      $("swpre").value = "";
    }

    // Swap ratio
    if (c.swpr) {
      $("swpr").value = c.swpr;
      $("swprValDisplay").textContent = c.swpr;
    }

    // Advanced fields
    ["mfkb", "efkb", "sflp", "sum", "scr", "scrd", "med", "low"].forEach((k) => {
      if ($(k)) $(k).value = c[k] || "";
    });

  } catch (err) {
    console.error("Config load error:", err);
  }
}

function collectConfigText() {
  const lines = [
    "# ZRAM Swap Configurator v4.0",
    "# Managed via WebUI — applied at boot or live"
  ];

  const add = (k, v) => {
    if (v !== null && v !== undefined && String(v).trim() !== "") {
      lines.push(`${k}=${String(v).trim()}`);
    }
  };

  const resizeVal = $("resize").value.trim();
  add("resize", resizeVal || "50%");
  add("algo", $("algo").value.trim());
  add("prio", $("prio").value.trim());
  add("swps", $("swps").value.trim());
  add("swpre", $("swpre").value.trim());
  add("swpr", $("swpr").value.trim());
  add("mfkb", $("mfkb").value.trim());
  add("efkb", $("efkb").value.trim());

  ["sflp", "sum", "scr", "scrd", "med", "low"].forEach((k) => {
    if ($(k)) add(k, $(k).value.trim());
  });

  return lines.join("\n") + "\n";
}

async function writeConfigFile(text) {
  const cmd = `cat > ${CONFIG_FILE} <<'EOF'\n${text}EOF`;
  return sh(cmd);
}

// ==================== PRESETS ====================
window.applyPreset = function(presetName) {
  switch (presetName) {
    case "battery":
      setSizeFromPct(35);
      selectAlgo("lz4");
      $("swps").value = "60";
      $("swpsSlider").value = 60;
      $("swpsValDisplay").textContent = "60";
      $("prio").value = "0";
      $("swpreCheck").checked = false;
      $("swpre").value = "0";
      $("swpr").value = "0";
      break;

    case "balanced":
      setSizeFromPct(50);
      selectAlgo("lz4");
      $("swps").value = "80";
      $("swpsSlider").value = 80;
      $("swpsValDisplay").textContent = "80";
      $("prio").value = "0";
      $("swpreCheck").checked = false;
      $("swpre").value = "";
      $("swpr").value = "";
      break;

    case "performance":
      setSizeFromPct(65);
      selectAlgo("lz4");
      $("swps").value = "100";
      $("swpsSlider").value = 100;
      $("swpsValDisplay").textContent = "100";
      $("prio").value = "0";
      $("swpreCheck").checked = false;
      $("swpre").value = "";
      $("swpr").value = "";
      break;

    case "gaming":
      setSizeFromPct(75);
      selectAlgo("lz4");
      $("swps").value = "100";
      $("swpsSlider").value = 100;
      $("swpsValDisplay").textContent = "100";
      $("prio").value = "0";
      $("sflp").value = "10";
      $("sum").value = "90";
      break;
  }

  // Switch to Tuning Tab
  switchTab("tuning");
  showToast(`${presetName.toUpperCase()} profile loaded! Press Save or Apply Now.`);
};

// Helper for Advanced Tab tags
window.setField = function(id, val) {
  if ($(id)) {
    $(id).value = val;
    showToast(`Set ${id} = "${val || 'cleared'}"`);
  }
};

// ==================== TABS ====================
function switchTab(tabId) {
  state.currentTab = tabId;
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.tab === tabId);
  });
  document.querySelectorAll(".tab-panel").forEach((p) => {
    p.classList.toggle("active", p.id === "tab-" + tabId);
  });

  if (tabId === "logs") {
    loadRecentLogs();
  }
}

// ==================== SAVE & APPLY NOW ====================
async function handleSave() {
  const btn = $("btnSave");
  btn.disabled = true;
  try {
    const text = collectConfigText();
    await writeConfigFile(text);
    showToast("Configuration saved for next boot!", true);
  } catch (err) {
    showToast("Save failed: " + err.message, false);
  } finally {
    btn.disabled = false;
  }
}

async function handleApplyNow() {
  const modal = $("applyModal");
  const modalStep = $("modalStep");

  modal.classList.add("show");
  modalStep.textContent = "Writing config.prop...";

  try {
    const text = collectConfigText();
    await writeConfigFile(text);

    modalStep.textContent = "Executing apply.sh (live)...";

    // Run apply engine live (avoids 15s boot sleep)
    const res = await sh(`sh ${APPLY_SCRIPT} live 2>&1; echo __RESULT__:$?`);

    modalStep.textContent = "Refreshing kernel status...";

    // Append to log terminal
    const cleanLog = res.replace(/__RESULT__:\d+/, "").trim();
    $("logConsole").textContent = cleanLog || "Apply executed successfully.";

    await refreshStatus();
    modal.classList.remove("show");

    if (cleanLog.includes("swap busy")) {
      showToast("Swap was busy: config saved, will apply on next reboot", false);
    } else {
      showToast("ZRAM reconfigured & applied successfully!", true);
    }
  } catch (err) {
    modal.classList.remove("show");
    showToast("Apply failed: " + err.message, false);
    $("logConsole").textContent = "Error: " + err.message;
  }
}

// ==================== LOGS & DIAGNOSTICS ====================
async function loadRecentLogs() {
  const consoleEl = $("logConsole");
  consoleEl.textContent = "Reading apply.log...";
  try {
    const tail = await sh(`tail -n 60 ${LOG_FILE} 2>/dev/null || echo "No logs recorded yet."`);
    consoleEl.textContent = tail.trim();
    consoleEl.scrollTop = consoleEl.scrollHeight;
  } catch (err) {
    consoleEl.textContent = "Error loading logs: " + err.message;
  }
}

async function runDiagnostics() {
  const consoleEl = $("logConsole");
  consoleEl.textContent = "Running action.sh diagnostics...";
  try {
    const out = await sh(`sh ${ACTION_SCRIPT} 2>&1`);
    consoleEl.textContent = out.trim() || "No diagnostic output returned.";
    showToast("Diagnostics finished!");
  } catch (err) {
    consoleEl.textContent = "Diagnostics failed: " + err.message;
    showToast("Diagnostics error: " + err.message, false);
  }
}

function copyLogToClipboard() {
  const text = $("logConsole").textContent;
  if (!text) return;
  navigator.clipboard.writeText(text).then(() => {
    showToast("Log copied to clipboard!");
  }).catch(() => {
    showToast("Failed to copy log", false);
  });
}

// ==================== INITIALIZATION & EVENT LISTENERS ====================
function initEventListeners() {
  // Tab buttons
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
  });

  // Slider change
  $("resizeSlider").addEventListener("input", (e) => {
    const pct = parseInt(e.target.value, 10);
    $("resize").value = pct === 0 ? "0" : pct + "%";
    updateCalculatedPill();

    document.querySelectorAll("#quickSizeChips .chip-btn").forEach((btn) => {
      btn.classList.toggle("active", parseInt(btn.dataset.size, 10) === pct);
    });
  });

  // Custom text input
  $("resize").addEventListener("input", () => {
    updateCalculatedPill();
  });

  // Quick size chip buttons
  document.querySelectorAll("#quickSizeChips .chip-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const size = parseInt(btn.dataset.size, 10);
      setSizeFromPct(size);
    });
  });

  // Swappiness Slider
  $("swpsSlider").addEventListener("input", (e) => {
    const v = e.target.value;
    $("swps").value = v;
    $("swpsValDisplay").textContent = v;
  });

  // Swap Ratio Checkbox
  $("swpreCheck").addEventListener("change", (e) => {
    $("swpre").value = e.target.checked ? "1" : "0";
  });

  $("swpr").addEventListener("input", (e) => {
    $("swprValDisplay").textContent = e.target.value || "keep";
  });

  // Action Dock Buttons
  $("btnSave").addEventListener("click", handleSave);
  $("btnApply").addEventListener("click", handleApplyNow);
  $("btnRefresh").addEventListener("click", refreshStatus);

  // Log tab buttons
  $("btnDiag").addEventListener("click", runDiagnostics);
  $("btnCopyLog").addEventListener("click", copyLogToClipboard);
}

// Boot WebUI
window.addEventListener("DOMContentLoaded", async () => {
  initEventListeners();
  await loadConfig();
  await refreshStatus();
});