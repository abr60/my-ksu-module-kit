// ZRAM Swap Configurator v4.0 — WebUI controller
// Uses the KernelSU-Next injected global `ksu` object (ksu.exec).
// Config file lives in the module dir (survives reboots, wiped on uninstall).

const MOD = "/data/adb/modules/ZRAMSwapConfigurator";
const CONFIG = MOD + "/config.prop";
const DEFAULTS = MOD + "/defaults.prop";
const APPLY = MOD + "/apply.sh";

const $ = (id) => document.getElementById(id);
const msg = $("msg");

// ---- bridge ----
function sh(cmd) {
  return new Promise((resolve, reject) => {
    if (typeof ksu !== "undefined" && ksu.exec) {
      ksu.exec(cmd, (code, stdout, stderr) => {
        if (code === 0) resolve(stdout || "");
        else reject(new Error(stderr || "exit " + code));
      });
    } else {
      reject(new Error("ksu.exec unavailable — are you in KernelSU manager WebUI?"));
    }
  });
}

// ---- helpers ----
function parseCfg(text) {
  const out = {};
  (text || "").split("\n").forEach((line) => {
    const m = line.match(/^([a-zA-Z0-9_.-]+)=(.*)$/);
    if (m) out[m[1]] = m[2];
  });
  return out;
}

function fmtBytes(b) {
  b = parseInt(b || "0", 10);
  if (!b) return "0 B";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return b.toFixed(1) + " " + u[i];
}

// ---- status ----
async function refreshStatus() {
  const box = $("status");
  box.innerHTML = '<span class="muted">Loading…</span>';
  try {
    const [meminfo, swaps, disksize, algo, swappiness] = await Promise.all([
      sh("cat /proc/meminfo"),
      sh("cat /proc/swaps"),
      sh("cat /sys/block/zram0/disksize"),
      sh("cat /sys/block/zram0/comp_algorithm"),
      sh("cat /proc/sys/vm/swappiness"),
    ]);
    const mem = meminfo.split("\n").filter((l) => /MemTotal|MemAvailable/.test(l)).join("\n");
    box.textContent =
      mem + "\n\n" +
      "zram0 disksize : " + fmtBytes(disksize.trim()) + "\n" +
      "algorithm      : " + algo.trim() + "\n" +
      "swappiness     : " + swappiness.trim() + "\n\n" +
      swaps.trim();
  } catch (e) {
    box.textContent = "Error: " + e.message;
  }
}

// ---- load current config into fields ----
function fillForm(map) {
  $("resize").value = map.resize && map.resize.includes("%") ? map.resize.replace("%", "") : (map.resize || "");
  $("algo").value = map.algo || "";
  $("prio").value = map.prio || "";
  $("swps").value = map.swps || "";
  $("swpre").value = map.swpre || "";
  $("swpr").value = map.swpr || "";
  $("mfkb").value = map.mfkb || "";
  $("efkb").value = map.efkb || "";
  ["sflp", "sum", "scr", "scrd", "med", "low"].forEach((k) => ($(k).value = map[k] || ""));
}

async function loadConfig() {
  try {
    const cfg = await sh("cat " + CONFIG + " 2>/dev/null");
    fillForm(parseCfg(cfg));
    if (!cfg.trim()) msg.textContent = "No config yet — defaults apply (50% resize).";
  } catch (e) {
    msg.textContent = "Could not read config: " + e.message;
  }
}

// ---- build config.prop from form ----
function collectConfig() {
  const lines = [];
  const add = (k, v) => {
    if (v !== null && v !== undefined && String(v).trim() !== "") lines.push(k + "=" + String(v).trim());
  };
  const r = $("resize").value.trim();
  add("resize", r ? r + "%" : "");
  add("algo", $("algo").value.trim());
  add("prio", $("prio").value.trim());
  add("swps", $("swps").value.trim());
  add("swpre", $("swpre").value.trim());
  add("swpr", $("swpr").value.trim());
  add("mfkb", $("mfkb").value.trim());
  add("efkb", $("efkb").value.trim());
  ["sflp", "sum", "scr", "scrd", "med", "low"].forEach((k) => add(k, $(k).value.trim()));
  return lines.join("\n") + "\n";
}

function writeConfig(text) {
  // heredoc via sh to avoid quoting pain
  const esc = text.replace(/'/g, "'\\''");
  return sh("cat > " + CONFIG + " <<'EOF'\n" + text + "EOF");
}

// ---- actions ----
async function doSave() {
  msg.className = "msg";
  msg.textContent = "Saving…";
  try {
    await writeConfig(collectConfig());
    msg.textContent = "Saved. Will apply at next boot (or press Apply now).";
    msg.classList.add("ok");
    await loadConfig();
  } catch (e) {
    msg.textContent = "Save failed: " + e.message;
    msg.classList.add("err");
  }
}

async function doApply() {
  msg.className = "msg";
  msg.textContent = "Applying now… (zram may be busy; retry loop up to ~60s)";
  try {
    await doSave();
    const out = await sh("sh " + APPLY + "; echo __DONE__:$?");
    const tail = out.replace(/__DONE__:\d+/, "").trim().split("\n").slice(-25).join("\n");
    $("log").textContent = tail;
    msg.textContent = "Applied. Status below; verify with Refresh.";
    msg.classList.add("ok");
    await refreshStatus();
    await loadConfig();
  } catch (e) {
    msg.textContent = "Apply failed: " + e.message;
    msg.classList.add("err");
    $("log").textContent = String(e.message);
  }
}

// ---- wire up ----
$("btnRefresh").addEventListener("click", refreshStatus);
$("btnSave").addEventListener("click", doSave);
$("btnApply").addEventListener("click", doApply);

refreshStatus();
loadConfig();