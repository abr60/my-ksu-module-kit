#!/system/bin/sh

# ZRAM Swap Configurator v4.0 — apply engine
# Reads config.prop (one key=value per line) and applies every setting.
# Semantics:
#   absent key        = leave untouched
#   key=def           = restore ROM default from defaults.prop
#   key=unset         = delete prop (lmkd keys only)
#   resize: "NN%" percent of RAM | "NNNN" raw bytes | "0" = disable zram
#           (absent resize defaults to 50%)
# Used at boot (service.sh) and live ("Apply Now" from WebUI).
# Output: appended to $MODPATH/apply.log, status echoed to stdout.

MODPATH=${0%/*}
CONFIG=$MODPATH/config.prop
CONFDEF=$MODPATH/defaults.prop
LOGFILE=$MODPATH/apply.log
LMKD=/system/bin/lmkd
ZRAM=/block/zram0

# stderr goes to the log; stdout passes through (WebUI / service caller)
exec 2>>$LOGFILE
echo "=== apply $(date) ===" >>$LOGFILE

get_cfg() {   # $1=key -> value or empty
  [ -f "$CONFIG" ] || return 0
  sed -n "s|^$1=||p" $CONFIG | tail -n1
}
get_def() {   # $1=key -> ROM default or empty
  [ -f "$CONFDEF" ] || return 0
  sed -n "s|^$1=||p" $CONFDEF | tail -n1
}

RESIZE=`get_cfg resize`
ALGO=`get_cfg algo`
PRIO=`get_cfg prio`
SWPS=`get_cfg swps`
SWPRE=`get_cfg swpre`
SWPR=`get_cfg swpr`
MFKB=`get_cfg mfkb`
EFKB=`get_cfg efkb`

# ---------------- zram resize / algo / prio ----------------
DISKSIZEDEF=`cat /sys$ZRAM/disksize 2>/dev/null`
DISKSIZE=
if [ -z "$RESIZE" ]; then
  RESIZE=50%
fi
if [ "$RESIZE" != 0 ]; then
  if echo "$RESIZE" | grep -q %; then
    VALNUM=`echo "$RESIZE" | sed 's|%||g'`
    MemTotal=`awk '/MemTotal/ {print $2}' /proc/meminfo`
    let VALUE="$MemTotal * $VALNUM / 100"
    DISKSIZE=$VALUE\K
  else
    DISKSIZE=$RESIZE
  fi
fi

SWAPOFF=false
if grep -q /dev$ZRAM /proc/swaps; then
  for i in `seq 1 20`; do
    if swapoff /dev$ZRAM; then
      SWAPOFF=true
      break
    fi
    sleep 3
  done
  if grep -q /dev$ZRAM /proc/swaps; then
    SWAPOFF=false
  fi
else
  SWAPOFF=true
fi

if $SWAPOFF; then
  echo 1 > /sys$ZRAM/reset 2>/dev/null
  if [ -n "$ALGO" ] && [ "$ALGO" != def ]; then
    if grep -q "$ALGO" /sys$ZRAM/comp_algorithm; then
      echo "$ALGO" > /sys$ZRAM/comp_algorithm
      echo "algo: $ALGO"
    else
      echo "! algo $ALGO unsupported, keeping $(cat /sys$ZRAM/comp_algorithm)"
    fi
  fi
  if [ "$RESIZE" = 0 ]; then
    echo 0 > /sys$ZRAM/disksize
    echo "resize: zram DISABLED (0)"
  else
    echo "$DISKSIZE" > /sys$ZRAM/disksize
    mkswap /dev$ZRAM
    [ -z "$PRIO" ] || [ "$PRIO" = def ] && PRIO=0
    /system/bin/swapon /dev$ZRAM -p "$PRIO" \
      || /vendor/bin/swapon /dev$ZRAM -p "$PRIO" \
      || /system/vendor/bin/swapon /dev$ZRAM -p "$PRIO" \
      || swapon /dev$ZRAM
    echo "resize: $DISKSIZE (now $(cat /sys$ZRAM/disksize) B), prio $PRIO"
  fi
else
  echo "! swap busy after retries — zram NOT resized (config kept; applies at next boot)"
fi

# ---------------- wait boot complete (sysctls/props need it) ----------------
until [ "`getprop sys.boot_completed`" == 1 ]; do
  sleep 1
done

# ---------------- sysctl files (with def-restore) ----------------
wcfg() {  # $1=key $2=value-or-empty $3=procfile
  [ -z "$2" ] && return 0
  if [ "$2" = def ]; then
    D=`get_def $1`
    [ -n "$D" ] && echo "$D" > $3 && echo "$1: restored $D"
  else
    echo "$2" > $3 && echo "$1: $2"
  fi
}
[ -f /proc/sys/vm/swap_ratio_enable ] && wcfg swpre "$SWPRE" /proc/sys/vm/swap_ratio_enable
[ -f /proc/sys/vm/swap_ratio ] && wcfg swpr "$SWPR" /proc/sys/vm/swap_ratio
[ -f /proc/sys/vm/min_free_kbytes ] && wcfg mfkb "$MFKB" /proc/sys/vm/min_free_kbytes
[ -f /proc/sys/vm/extra_free_kbytes ] && wcfg efkb "$EFKB" /proc/sys/vm/extra_free_kbytes

# ---------------- lmkd props ----------------
LMK_REINIT=false
for NAME in swap_free_low_percentage swap_util_max swap_compression_ratio swap_compression_ratio_div medium low; do
  KEY=`echo $NAME | sed 's|swap_free_low_percentage|sflp|; s|swap_util_max|sum|; s|swap_compression_ratio_div|scrd|; s|swap_compression_ratio|scr|; s|medium|med|; s|^low$|low|'`
  VAL=`get_cfg $KEY`
  [ -z "$VAL" ] && continue
  PROP=persist.device_config.lmkd_native.$NAME
  PROP2=ro.lmk.$NAME
  if ! grep -q $PROP $LMKD && grep -q $PROP2 $LMKD; then
    PROP=$PROP2
  fi
  if [ "$VAL" = unset ]; then
    resetprop -p --delete $PROP
    echo "lmk $KEY: unset ($PROP)"
    LMK_REINIT=true
  elif [ "$VAL" = def ]; then
    D=`get_def $KEY`
    resetprop -p --delete $PROP
    if [ -n "$D" ]; then
      resetprop -n $PROP "$D"
      echo "lmk $KEY: restored $D"
    else
      echo "lmk $KEY: def but no recorded default"
    fi
    LMK_REINIT=true
  else
    resetprop -p --delete $PROP
    resetprop -n $PROP "$VAL"
    echo "lmk $KEY: $VAL ($PROP)"
    LMK_REINIT=true
  fi
done
[ "$LMK_REINIT" = true ] && resetprop lmkd.reinit 1

# ---------------- swappiness ----------------
sleep 15
[ -f /proc/sys/vm/swappiness ] && wcfg swps "$SWPS" /proc/sys/vm/swappiness

echo "=== done ==="