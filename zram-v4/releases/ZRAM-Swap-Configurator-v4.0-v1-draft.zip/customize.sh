#!/system/bin/sh

# ZRAM Swap Configurator v4.0 — apply engine
# Reads config.prop (one key=value per line) and applies settings.
# Values: absent key = leave untouched; "def" = restore ROM default
# (recorded in defaults.prop by customize.sh); "unset" = delete prop (lmkd).
# resize: "NN%" percent of RAM | "NNNN" raw bytes | "0" = disable zram |
#         absent = default 50% of RAM.

# space
ui_print " "

# var
UID=`id -u`
[ ! "$UID" ] && UID=0
DEFFILE=/data/adb/modules/$MODID/debug.log
LMKD=/system/bin/lmkd
CONFIG=$MODPATH/config.prop
CONFDEF=$MODPATH/defaults.prop

# optionals
OPTIONALS=/data/media/"$UID"/optionals.prop
if [ ! -f $OPTIONALS ]; then
  touch $OPTIONALS
fi

# debug
if [ "`grep_prop debug.log $OPTIONALS`" == 1 ]; then
  ui_print "- The install log will contain detailed information"
  set -x
  ui_print " "
fi

# info
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " ID=$MODID"
ui_print " Version=$MODVER"
ui_print " VersionCode=$MODVERCODE"
if [ "$KSU" == true ]; then
  ui_print " KSUVersion=$KSU_VER"
  ui_print " KSUVersionCode=$KSU_VER_CODE"
  ui_print " KSUKernelVersionCode=$KSU_KERNEL_VER_CODE"
else
  ui_print " MagiskVersion=$MAGISK_VER"
  ui_print " MagiskVersionCode=$MAGISK_VER_CODE"
fi
ui_print " "

# cleaning
rm -rf $MODPATH/image
rm -f $CONFIG $CONFDEF

# helper to persist a key only when an explicit value is set
cfg() {  # cfg <key> <value>
  [ -n "$2" ] && echo "$1=$2" >> $CONFIG
}
cfgdef() {  # cfgdef <key> <value>  (always record, even empty)
  echo "$1=$2" >> $CONFDEF
}

# ---- defaults capture (ROM stock values for later "def" restore) ----
FILE=/proc/sys/vm/swappiness
[ -f $FILE ] && cfgdef swps `cat $FILE`
FILE=/proc/sys/vm/swap_ratio_enable
[ -f $FILE ] && cfgdef swpre `cat $FILE`
FILE=/proc/sys/vm/swap_ratio
[ -f $FILE ] && cfgdef swpr `cat $FILE`
FILE=/proc/sys/vm/min_free_kbytes
[ -f $FILE ] && cfgdef mfkb `cat $FILE`
FILE=/proc/sys/vm/extra_free_kbytes
[ -f $FILE ] && cfgdef efkb `cat $FILE`
for NAME in swap_free_low_percentage swap_util_max swap_compression_ratio swap_compression_ratio_div medium low; do
  KEY=`echo $NAME | sed 's|swap_free_low_percentage|sflp|; s|swap_util_max|sum|; s|swap_compression_ratio_div|scrd|; s|swap_compression_ratio|scr|; s|medium|med|; s|^low$|low|'`
  PROP=persist.device_config.lmkd_native.$NAME
  PROP2=ro.lmk.$NAME
  if ! grep -q $PROP $LMKD && grep -q $PROP2 $LMKD; then
    PROP=$PROP2
  fi
  CUR=`getprop $PROP`
  [ -n "$CUR" ] && cfgdef $KEY $CUR
done

# ---- free & swaps status ----
ui_print "- Current free:"
/system/bin/free
ui_print " "
ui_print "- Current /proc/swaps:"
cat /proc/swaps
ui_print " "

# ---- resize ----
VAL=`grep_prop zram.resize $OPTIONALS`
ZRAM=/block/zram0
FILE=/sys$ZRAM/disksize
FILE2=/sys$ZRAM/comp_algorithm
CUR=`cat $FILE`
CUR2=`cat $FILE2`
ui_print "- Current $FILE"
ui_print "  = $CUR Byte"
ui_print " "
ui_print "- Current $FILE2"
ui_print "  = $CUR2"
ui_print " "
if [ -z "$VAL" ] || [ "$VAL" == def ]; then
  VAL=50%
fi
if [ "$VAL" == 0 ]; then
  ui_print "- Disables ZRAM Swap."
  cfg resize 0
else
  if echo "$VAL" | grep -q %; then
    ui_print "- Changes $FILE to $VAL of RAM size."
    VALNUM=`echo "$VAL" | sed 's|%||g'`
    MemTotal=`awk '/MemTotal/ {print $2}' /proc/meminfo`
    let RES="$MemTotal * $VALNUM / 100 * 1024"
    ui_print "  ($RES Byte)"
    cfg resize $VAL
  else
    ui_print "- Changes $FILE to $VAL Byte."
    cfg resize $VAL
  fi
fi
ui_print " "

# ---- algo ----
VAL=`grep_prop zram.algo $OPTIONALS`
if [ -n "$VAL" ] && [ "$VAL" != def ] && [ "$VAL" != unset ]; then
  if grep -q "$VAL" $FILE2; then
    ui_print "- Changes $FILE2 to $VAL"
    cfg algo $VAL
  else
    ui_print "! $VAL is unsupported in $FILE2"
  fi
fi
ui_print " "

# ---- prio ----
VAL=`grep_prop zram.prio $OPTIONALS`
if [ -n "$VAL" ] && [ "$VAL" != def ] && [ "$VAL" != 0 ]; then
  ui_print "- Sets swap priority to $VAL"
  cfg prio $VAL
else
  ui_print "- Sets swap priority to 0"
  cfg prio 0
fi
ui_print " "

# ---- swappiness ----
VAL=`grep_prop zram.swps $OPTIONALS`
if [ -n "$VAL" ]; then
  if [ "$VAL" -gt 100 ] 2>/dev/null; then VAL=100; fi
  if [ "$VAL" -lt 0 ] 2>/dev/null; then unset VAL; fi
  if [ -n "$VAL" ] && [ "$VAL" != def ]; then
    ui_print "- Changes swappiness to $VAL"
    cfg swps $VAL
    if [ -f /proc/sys/vm/swappiness ] && [ "$BOOTMODE" == true ]; then
      echo "$VAL" > /proc/sys/vm/swappiness
      ui_print "  This change does not require reboot."
    fi
  elif [ "$VAL" == def ]; then
    ui_print "- Restores swappiness to default"
    cfg swps def
  fi
fi
ui_print " "

# ---- swap_ratio_enable & swap_ratio ----
VAL=`grep_prop zram.swpre $OPTIONALS`
if [ -n "$VAL" ]; then
  if [ "$VAL" == 0 ] || [ "$VAL" == 1 ]; then
    ui_print "- Changes swap_ratio_enable to $VAL"
    cfg swpre $VAL
    if [ -f /proc/sys/vm/swap_ratio_enable ] && [ "$BOOTMODE" == true ]; then
      echo "$VAL" > /proc/sys/vm/swap_ratio_enable
    fi
    if [ "$VAL" == 1 ]; then
      VAL2=`grep_prop zram.swpr $OPTIONALS`
      if [ -n "$VAL2" ]; then
        if [ "$VAL2" -gt 100 ] 2>/dev/null; then VAL2=100; fi
        if [ "$VAL2" -lt 0 ] 2>/dev/null; then unset VAL2; fi
        if [ -n "$VAL2" ] && [ "$VAL2" != def ]; then
          ui_print "- Changes swap_ratio to $VAL2"
          cfg swpr $VAL2
          [ -f /proc/sys/vm/swap_ratio ] && echo "$VAL2" > /proc/sys/vm/swap_ratio
        elif [ "$VAL2" == def ]; then
          ui_print "- Restores swap_ratio to default"
          cfg swpr def
        fi
      fi
    fi
  elif [ "$VAL" == def ]; then
    ui_print "- Restores swap_ratio_enable to default"
    cfg swpre def
  fi
fi
ui_print " "

# ---- min_free_kbytes / extra_free_kbytes ----
for KEY in mfkb efkb; do
  VAL=`grep_prop zram.$KEY $OPTIONALS`
  if [ -n "$VAL" ]; then
    if [ "$VAL" != def ]; then
      ui_print "- Changes $KEY to $VAL"
      cfg $KEY $VAL
      if [ "$BOOTMODE" == true ]; then
        if [ "$KEY" == mfkb ] && [ -f /proc/sys/vm/min_free_kbytes ]; then
          echo "$VAL" > /proc/sys/vm/min_free_kbytes
        fi
        if [ "$KEY" == efkb ] && [ -f /proc/sys/vm/extra_free_kbytes ]; then
          echo "$VAL" > /proc/sys/vm/extra_free_kbytes
        fi
      fi
    else
      ui_print "- Restores $KEY to default"
      cfg $KEY def
    fi
  fi
done
ui_print " "

# ---- lmkd props (sflp sum scr scrd med low) ----
for NAME in swap_free_low_percentage swap_util_max swap_compression_ratio swap_compression_ratio_div medium low; do
  KEY=`echo $NAME | sed 's|swap_free_low_percentage|sflp|; s|swap_util_max|sum|; s|swap_compression_ratio_div|scrd|; s|swap_compression_ratio|scr|; s|medium|med|; s|low|low|'`
  VAL=`grep_prop zram.$KEY $OPTIONALS`
  if [ -n "$VAL" ]; then
    PROP=persist.device_config.lmkd_native.$NAME
    PROP2=ro.lmk.$NAME
    if ! grep -q $PROP $LMKD && grep -q $PROP2 $LMKD; then
      PROP=$PROP2
    fi
    if grep -q $PROP $LMKD; then
      if [ "$VAL" == unset ]; then
        ui_print "- Unsets lmk $NAME"
        cfg $KEY unset
        [ "$BOOTMODE" == true ] && resetprop -p --delete $PROP
      elif [ "$VAL" == def ]; then
        ui_print "- Restores lmk $NAME to default"
        cfg $KEY def
      else
        if [ "$VAL" -gt 100 ] 2>/dev/null; then VAL=100; fi
        if [ "$VAL" -lt 0 ] 2>/dev/null; then VAL=0; fi
        ui_print "- Changes lmk $NAME to $VAL"
        cfg $KEY $VAL
        [ "$BOOTMODE" == true ] && resetprop -n $PROP "$VAL"
      fi
      [ "$BOOTMODE" == true ] && resetprop lmkd.reinit 1
    else
      ui_print "! This ROM does not support lmk $NAME parameter"
    fi
  fi
done
ui_print " "

# ---- final config preview ----
ui_print "- Config written to $CONFIG:"
cat $CONFIG
ui_print " "

# copy action
mkdir -p `dirname $DEFFILE`
cp -f $MODPATH/action.sh `dirname $DEFFILE`

# space
ui_print " "
ui_print " "
ui_print " "
ui_print " "
ui_print " "
ui_print " "
ui_print " "
ui_print " "
ui_print " "
ui_print " "