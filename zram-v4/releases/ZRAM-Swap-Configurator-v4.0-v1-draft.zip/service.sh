#!/system/bin/sh

# ZRAM Swap Configurator v4.0 — boot entry
# Thin wrapper: runs apply.sh (reads config.prop + defaults.prop).
# stdout/stderr tee'd into apply.log.

MODPATH=${0%/*}
LOGFILE=$MODPATH/apply.log

sh $MODPATH/apply.sh 2>&1 | tee -a $LOGFILE
exit 0