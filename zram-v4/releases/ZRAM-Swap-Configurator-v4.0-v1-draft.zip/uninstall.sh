#!/system/bin/sh

# ZRAM Swap Configurator v4.0 — uninstall cleanup
# Removes runtime state so a full remove is truly clean.

MODPATH=${0%/*}

rm -f $MODPATH/config.prop
rm -f $MODPATH/defaults.prop
rm -f $MODPATH/apply.log
rm -f $MODPATH/debug.log
rm -f $MODPATH/setting
rm -rf /data/adb/modules_update/ZRAMSwapConfigurator

exit 0